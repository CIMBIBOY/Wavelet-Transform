package wavelet;

import java.awt.BorderLayout;
import java.awt.event.ItemEvent;

import javax.swing.JOptionPane;

public class Main {

    private static ImageManipulation image = new ImageManipulation();
    private static MenuFrame menuFrame;
    // private static Matrix mMatrix = new Matrix();;

    public static void main(String[] args) 
    {
        // Gui instance
        menuFrame = new MenuFrame();
        
        menuFrame.getLoadMenuItem().addActionListener(e -> 
        {
            if(image.LoadImage() == false) {
                JOptionPane.showMessageDialog(menuFrame.getFrame(), "A kép betöltése sikertelen!\nMérete vagy típusa nem megfelelő!\nA kép követelményei:\nszélesség és magasság = 2^n\n-min 16*16 pixel\n-max 16384*16384 pixel\nSzürkeárnyalatos kép", "Hiba", JOptionPane.ERROR_MESSAGE);
                return;
            }
            // felület törlése
            menuFrame.getFrame().getContentPane().removeAll();

            // címke kitűzése a menübe a képpel
            menuFrame.getFrame().add(image.getLabel(), BorderLayout.CENTER);

            // menü frissítése
            menuFrame.getFrame().revalidate();

            // float matrix[][] = mMatrix.matrixFromImage(image.getBuffImage());
            // mMatrix.saveMatrixToFile(matrix, "D:\\Egyetem\\Prog\\Prog3\\Nagyhazi\\matrix.txt");
        });

        menuFrame.getDaubComboBox().addItemListener(e -> 
        {
            if (e.getStateChange() == ItemEvent.SELECTED) {
                Object paramNum = menuFrame.getDaubComboBox().getSelectedItem();
                System.out.println(paramNum);
                if (paramNum != null && paramNum instanceof Integer) {
                    int param = (int) paramNum;
                    switch (param) {
                    case 1:
                        System.out.println("Sikeres Transzformáció 1-es paraméter használatával");
                        break;
                    case 2:
                        System.out.println("Sikeres Transzformáció 2-es paraméter használatával"); 
                        break;
                    case 3:
                        JOptionPane.showMessageDialog(menuFrame.getFrame(), "3-as paraméter használatával", "Sikeres Transzformáció", JOptionPane.ERROR_MESSAGE);
                        break;
                    case 4:
                        JOptionPane.showMessageDialog(menuFrame.getFrame(), "4-es paraméter használatával", "Sikeres Transzformáció", JOptionPane.ERROR_MESSAGE);
                        break;
                    case 5:
                        JOptionPane.showMessageDialog(menuFrame.getFrame(), "5-ös paraméter használatával", "Sikeres Transzformáció", JOptionPane.ERROR_MESSAGE);
                        break;
                    case 6:
                        JOptionPane.showMessageDialog(menuFrame.getFrame(), "6-os paraméter használatával", "Sikeres Transzformáció", JOptionPane.ERROR_MESSAGE);
                        break;
                    case 7:
                        JOptionPane.showMessageDialog(menuFrame.getFrame(), "7-es paraméter használatával", "Sikeres Transzformáció", JOptionPane.ERROR_MESSAGE);
                        break;
                    case 8:
                        JOptionPane.showMessageDialog(menuFrame.getFrame(), "8-as paraméter használatával", "Sikeres Transzformáció", JOptionPane.ERROR_MESSAGE);
                        break;
                    case 9:
                        JOptionPane.showMessageDialog(menuFrame.getFrame(), "9-es paraméter használatával", "Sikeres Transzformáció", JOptionPane.ERROR_MESSAGE);
                        break;
                    case 10:
                        JOptionPane.showMessageDialog(menuFrame.getFrame(), "10-es paraméter használatával", "Sikeres Transzformáció", JOptionPane.ERROR_MESSAGE);
                        break;
                }
            }
        }
    });

        menuFrame.getSaveMenuItem().addActionListener(e -> {


            if(image.SaveImage()==false)
            {
                JOptionPane.showMessageDialog(menuFrame.getFrame(), "A kép mentése sikertelen!", "Hiba", JOptionPane.ERROR_MESSAGE);
                return;
            };
        });

        // menü exit opció implementálása - lambda function call 
        menuFrame.getExitMenuItem().addActionListener(e -> 
        {
            int option = JOptionPane.showConfirmDialog(null, "Valóban ki szeretnél lépni?", "Kilépés", JOptionPane.YES_NO_OPTION);
            if (option == JOptionPane.YES_OPTION) 
            {
                System.exit(0); // kilépés 
            }
        });
    }
}

