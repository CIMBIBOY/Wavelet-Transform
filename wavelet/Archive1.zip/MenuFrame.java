package wavelet;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MenuFrame implements ActionListener
{
    private JFrame frame; // creating frame
    private JMenuBar menuBar; // creating menu bar 
    private JMenu fileMenu; // menu itself
    private JMenuItem loadMenuItem; // creating items 
    private JMenuItem saveMenuItem; 
    private JMenuItem exitMenuItem;

    private JMenu waveletParametersMenu;
    private JComboBox<Integer> daubComboBox; 

    private JMenu cutParametersMenu;
    private JComboBox<Integer> cutComboBox;

    private JMenuItem reverseMenuItem;

    public MenuFrame()
    {
        initialize();
    }

    private void initialize()
    {
        frame = new JFrame(); // instence
        frame.setTitle("Wavelet Transformer Menu"); // title 
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // alap bezárási művelet
        frame.setSize(1400, 800); // alkalmazás nagyság
        frame.setLayout(new BorderLayout(10,10)); // alap háttér
        frame.setLocationRelativeTo(null); // alap elhelyezés

        Font f = new Font("SansSerif", Font.PLAIN, 18); // betütípus 
        UIManager.put("Menu.font", f);
        UIManager.put("MenuItem.font", f);
        UIManager.put("CheckBoxMenuItem.font", f);
        UIManager.put("RadioButtonMenuItem.font", f);

        // maga a menu
        menuBar = new JMenuBar();

        fileMenu = new JMenu("File");

        // példányok
        loadMenuItem = new JMenuItem("Fájl Betöltés");
        loadMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_L, ActionEvent.CTRL_MASK));
        loadMenuItem.addActionListener(this);

        saveMenuItem = new JMenuItem("Fájl Kimentés");
        saveMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_K, ActionEvent.CTRL_MASK));
        saveMenuItem.addActionListener(this);

        exitMenuItem = new JMenuItem("Kilépés");
        exitMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_E, ActionEvent.CTRL_MASK));
        exitMenuItem.addActionListener(this);

        waveletParametersMenu = new JMenu("Wavelet Paraméterek:");
        cutParametersMenu = new JMenu("Vágás Paraméterek:");

        reverseMenuItem = new JMenuItem("Vissza Transzformáció");

        // itemek hozzáadása
        fileMenu.add(loadMenuItem);

        // Daubechies ComboBox inicializálása a paraméterekkel
        Integer[] daubParams = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        daubComboBox = new JComboBox<>(daubParams);
        daubComboBox.setEnabled(true);
        waveletParametersMenu.add(daubComboBox);

        // Vágás ComboBox inicializálása a vágási paraméterekkel
        Integer[] cutParams = {2, 4, 8, 16};
        cutComboBox = new JComboBox<>(cutParams);
        cutComboBox.setEnabled(true);
        cutParametersMenu.add(cutComboBox);

        fileMenu.add(waveletParametersMenu);
        fileMenu.add(cutParametersMenu);

        fileMenu.add(reverseMenuItem);
        fileMenu.add(saveMenuItem);
        fileMenu.add(exitMenuItem);

        // bar hozzáadása
        menuBar.add(fileMenu);

        // bar beállítása
        frame.setJMenuBar(menuBar);

        frame.setVisible(true);
    }

    @Override // akció végrehajtó
    public void actionPerformed(ActionEvent e) 
    {
        System.out.println("Végrehajtva: " + e.getActionCommand());
    }

    // frame getter
    public JFrame getFrame()
    { 
        return frame;
    }

    // item getterek main callhoz
    public JMenuItem getLoadMenuItem() 
    {
        return loadMenuItem;
    }

    public JComboBox<Integer> getDaubComboBox()
    {
        return daubComboBox;
    }

    public JComboBox<Integer> getCutComboBox()
    {
        return cutComboBox;
    }

    public JMenuItem getReverseMenuItem() {
        return reverseMenuItem;
    }

    public JMenuItem getSaveMenuItem() {
        return saveMenuItem;
    }

    public JMenuItem getExitMenuItem() {
        return exitMenuItem;
    }
}

