package wavelet;

public class Cut {
    
}
