package wavelet;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

public class Matrix {
    
    public float[][] matrixFromImage(BufferedImage image) {
        int width = image.getWidth();
        int height = image.getHeight();
        float[][] matrix = new float[height][width];
    
        for (int i = 0; i < height; i++) {
            for (int j = 0; j < width; j++) {
                int grayValue = image.getRaster().getSample(j, i, 0); // greyscale values
                matrix[i][j] = (float) grayValue;
            }
        }
    
        return matrix;
    }
    
    public BufferedImage imageFromMatrix(float[][] matrix) {
        int width = matrix[0].length;
        int height = matrix.length;
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_BYTE_GRAY);
    
        for (int i = 0; i < height; i++) {
            for (int j = 0; j < width; j++) {
                int grayValue = Math.round(matrix[i][j]);
                image.getRaster().setSample(j, i, 0, grayValue);
            }
        }
    
        return image;
    }
    
    public void saveMatrixToFile(float[][] matrix, String filePath) 
    {
        File file = new File(filePath);

        try (PrintWriter writer = new PrintWriter(file)) {
            for (int i = 0; i < matrix.length; i++) {
                for (int j = 0; j < matrix[i].length; j++) {
                    writer.print(matrix[i][j] + " ");
                }
                writer.println();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
